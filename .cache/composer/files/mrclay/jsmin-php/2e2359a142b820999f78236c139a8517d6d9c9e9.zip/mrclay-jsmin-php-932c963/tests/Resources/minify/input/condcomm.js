var isWin;
/*@cc_on
    @if (@_win32)
        isWin = true;
    @else @*/ isWin = false;
   /*@end
@*/

isWin = /*@cc_on!*/!1;

var recognizesCondComm = true;
//@cc_on/*
recognizesCondComm = false;
//@cc_on*/

function testIssue74() {
    return /'/;
}

!function(s) {
    return /^[£$€?.]/.test(s);
}();

typeof  
    / ' /;

x = / [/] /;

1

/ foo;

(2)

/ foo;

function(){return/foo/};

function(){return typeof/foo/};

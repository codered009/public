<?php

namespace TestDocuments;

class EmbeddedDocument
{
    public $name;
}

<?php echo $view['form']->block($form, 'button_widget', ['type' => isset($type) ? $type : 'reset']) ?>

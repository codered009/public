<?php

namespace Doctrine\ODM\MongoDB\Tests\Mocks;

class ConnectionMock extends \Doctrine\MongoDB\Connection
{
}
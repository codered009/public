<?php

namespace JMS\TranslationBundle\Tests\Functional\Fixture\TestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TestBundle extends Bundle
{
}

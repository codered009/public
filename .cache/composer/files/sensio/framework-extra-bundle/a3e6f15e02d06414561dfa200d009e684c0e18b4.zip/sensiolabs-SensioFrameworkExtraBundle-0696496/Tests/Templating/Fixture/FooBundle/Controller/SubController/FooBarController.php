<?php

namespace Sensio\Bundle\FrameworkExtraBundle\Tests\Templating\Fixture\FooBundle\Controller\SubController;

class FooBarController
{
}

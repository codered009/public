<?php echo $view['form']->formEncodeCurrency($money_pattern, $view['form']->block($form, 'form_widget_simple')) ?>

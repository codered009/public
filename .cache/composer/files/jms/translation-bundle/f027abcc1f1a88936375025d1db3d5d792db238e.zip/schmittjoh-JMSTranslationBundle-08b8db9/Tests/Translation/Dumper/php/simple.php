<?php
return array(
    'foo' => 'foo', // FIXME
);

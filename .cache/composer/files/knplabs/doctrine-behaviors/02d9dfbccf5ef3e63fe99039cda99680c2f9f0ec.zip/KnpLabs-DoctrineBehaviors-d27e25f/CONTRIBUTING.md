# Contributing

Please make sure the test suite runs fine before and after contributing.

## Running the tests

Everything you need to do before running the test appears in `.travis.yml`. Make
sure you run the phpunit version bundled with the library, like this :

    bin/phpunit

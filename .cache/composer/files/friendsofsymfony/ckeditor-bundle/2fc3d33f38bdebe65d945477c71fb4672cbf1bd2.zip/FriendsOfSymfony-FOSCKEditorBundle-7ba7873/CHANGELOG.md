# CHANGELOG

## [1.1.0](https://github.com/FriendsOfSymfony/FOSCKEditorBundle/compare/1.0.0...1.1.0) - 2018-05-25
### Added
- Deprecation message for IvoryCKEditorBundle

### Changed
- The command is now lazy loaded in Symfony 3.4+

### Fixed
- `ckeditor:install` command not working with `--no-interaction`


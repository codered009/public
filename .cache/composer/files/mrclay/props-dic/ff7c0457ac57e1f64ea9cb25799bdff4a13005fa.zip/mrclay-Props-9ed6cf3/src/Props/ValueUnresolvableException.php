<?php

namespace Props;

use Interop\Container\Exception\ContainerException;

class ValueUnresolvableException extends \Exception implements ContainerException
{
}

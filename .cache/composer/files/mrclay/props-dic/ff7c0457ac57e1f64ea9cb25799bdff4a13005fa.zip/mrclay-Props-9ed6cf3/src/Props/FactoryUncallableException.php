<?php

namespace Props;

use Interop\Container\Exception\ContainerException;

class FactoryUncallableException extends \Exception implements ContainerException
{
}

CHANGELOG for 2.x
=================

- No support of Gedmo 2.3.x

- New a2lix_translatedEntity field (see https://github.com/a2lix/TranslationFormBundle/issues/94#issuecomment-30613988)

- 'default_required' (boolean) option is replaced by 'required_locales' (array)

<?php
return array(
    // Desc: bar
    // Meaning: baz
    'foo' => 'bar', // FIXME
);

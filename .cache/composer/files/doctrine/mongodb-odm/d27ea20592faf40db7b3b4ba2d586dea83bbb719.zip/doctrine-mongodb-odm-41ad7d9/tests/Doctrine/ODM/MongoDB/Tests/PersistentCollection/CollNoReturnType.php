<?php

namespace Doctrine\ODM\MongoDB\Tests\PersistentCollection;

use Doctrine\Common\Collections\ArrayCollection;

class CollNoReturnType extends ArrayCollection
{

}

<?php
return array(
    'foo' => array(
        'bar' => array(
            'baz' => 'foo.bar.baz', // FIXME
        ),
    ),
);

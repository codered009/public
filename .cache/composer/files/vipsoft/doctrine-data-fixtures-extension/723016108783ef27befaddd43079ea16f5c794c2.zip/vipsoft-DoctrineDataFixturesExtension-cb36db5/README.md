# DoctrineDataFixturesExtension

Increase feature test isolation by reloading ORM data fixtures between features.

## Documentation

[Official documentation](http://extensions.behat.org/doctrine-data-fixtures/index.html)

## Source

[Github](https://github.com/vipsoft/DoctrineDataFixturesExtension)

## Copyright

Copyright (c) 2012 Anthon Pang. See LICENSE for details.

## Credits

* Anthon Pang [robocoder](http://github.com/robocoder)
* Konstantin Kudryashov [everzet](http://github.com/everzet) - init.php and build.php
* [Others](https://github.com/vipsoft/DoctrineDataFixturesExtension/graphs/contributors)

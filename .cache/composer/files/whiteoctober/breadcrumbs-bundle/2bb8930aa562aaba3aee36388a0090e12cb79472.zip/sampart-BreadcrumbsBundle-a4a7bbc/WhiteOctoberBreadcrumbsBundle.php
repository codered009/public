<?php

namespace WhiteOctober\BreadcrumbsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WhiteOctoberBreadcrumbsBundle extends Bundle
{
}

UPGRADE FROM 1.x to 2.0
=======================

### [BC Break] Gedmo stragegy compatible only with wip2.4/3.0 version (https://github.com/l3pp4rd/DoctrineExtensions/pull/764)

### [BC Break] 'default_required' (boolean) option is replaced by 'required_locales' (array)

<?php

namespace TestDocuments;

class InvalidPartialFilterDocument
{
    protected $id;
}

<?php

namespace Props;

use Interop\Container\Exception\ContainerException;

class BadMethodCallException extends \Exception implements ContainerException
{
}

<?php

namespace Liip\ImagineBundle\Async;

class Topics
{
    const RESOLVE_CACHE = 'liip_imagine_resolve_cache';

    const CACHE_RESOLVED = 'liip_imagine_cache_resolved';
}

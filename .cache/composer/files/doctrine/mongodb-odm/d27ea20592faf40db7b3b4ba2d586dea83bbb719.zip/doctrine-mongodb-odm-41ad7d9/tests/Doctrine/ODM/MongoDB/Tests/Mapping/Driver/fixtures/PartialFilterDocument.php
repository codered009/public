<?php

namespace TestDocuments;

class PartialFilterDocument
{
    protected $id;
}

<?php

namespace JSMin;

class UnterminatedStringException extends \Exception {
}

#!/bin/bash
sphinx-build en build

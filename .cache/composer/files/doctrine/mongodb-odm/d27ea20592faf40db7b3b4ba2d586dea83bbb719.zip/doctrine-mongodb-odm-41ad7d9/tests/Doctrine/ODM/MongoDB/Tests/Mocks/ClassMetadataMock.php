<?php

namespace Doctrine\ODM\MongoDB\Tests\Mocks;

class ClassMetadataMock extends \Doctrine\ODM\MongoDB\Mapping\ClassMetadata
{
}
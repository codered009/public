<?php

class ComposerAutoloaderInitFake
{
}

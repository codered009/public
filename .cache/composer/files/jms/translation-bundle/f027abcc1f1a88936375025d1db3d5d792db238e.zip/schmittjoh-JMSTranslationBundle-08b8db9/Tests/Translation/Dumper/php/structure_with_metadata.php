<?php
return array(
    'foo' => array(
        'bar' => array(
            // Desc: Foo
            'baz' => 'Foo', // FIXME

            // Meaning: Bar
            'moo' => 'foo.bar.moo', // FIXME
        ),

        'baz' => 'foo.baz', // FIXME
    ),
);

#!/usr/bin/env bash

pip install -r docs/requirements.txt --user

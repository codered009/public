<?php

namespace Buzz\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}

<?php

namespace SimpleThings\EntityAudit\Tests\Fixtures\Relation;

class UnManagedIndexByOwner
{

}

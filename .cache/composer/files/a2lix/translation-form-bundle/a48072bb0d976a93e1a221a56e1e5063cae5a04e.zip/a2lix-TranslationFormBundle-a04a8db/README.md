A2lixTranslationFormBundle
==========================

[![SensioLabsInsight](https://insight.sensiolabs.com/projects/64aee70e-7b00-406f-8648-f7ea66e29f80/mini.png)](https://insight.sensiolabs.com/projects/64aee70e-7b00-406f-8648-f7ea66e29f80)
[![Latest Stable Version](https://poser.pugx.org/a2lix/translation-form-bundle/v/stable.svg)](https://packagist.org/packages/a2lix/translation-form-bundle) [![Total Downloads](https://poser.pugx.org/a2lix/translation-form-bundle/downloads.svg)](https://packagist.org/packages/a2lix/translation-form-bundle) [![Latest Unstable Version](https://poser.pugx.org/a2lix/translation-form-bundle/v/unstable.svg)](https://packagist.org/packages/a2lix/translation-form-bundle) [![License](https://poser.pugx.org/a2lix/translation-form-bundle/license.svg)](https://packagist.org/packages/a2lix/translation-form-bundle)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/a2lix/TranslationFormBundle/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/a2lix/TranslationFormBundle/?branch=master)

* If you use symfony 2.2 or less, configure your composer.json with:
 * "a2lix/translation-form-bundle": "0.*@dev"

--> Documentation: https://github.com/a2lix/TranslationFormBundle/blob/0.x/README.md




* If you use symfony 2.3 or more, configure your composer.json with :
 * "a2lix/translation-form-bundle": "1.*@dev"     if you need to use the old Gedmo strategy
 * "a2lix/translation-form-bundle": "2.*@dev"     otherwise (Manage wip2.4 Gedmo, A2lix, Knp and Prezent strategy)

--> New Documentation: http://a2lix.fr/bundles/translation-form/

<?php
return array(
    'foo.bar.baz' => 'foo.bar.baz', // FIXME
);

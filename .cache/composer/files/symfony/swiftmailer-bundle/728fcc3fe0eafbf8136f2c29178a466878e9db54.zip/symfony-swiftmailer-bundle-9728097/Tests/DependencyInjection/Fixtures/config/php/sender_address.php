<?php

$container->loadFromExtension('swiftmailer', array(
    'sender_address' => 'noreply@test.com',
));

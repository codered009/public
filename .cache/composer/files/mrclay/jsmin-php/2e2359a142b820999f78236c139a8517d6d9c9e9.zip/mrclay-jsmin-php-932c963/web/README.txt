This can be placed in webroot to allow easy direct testing of JSMin.


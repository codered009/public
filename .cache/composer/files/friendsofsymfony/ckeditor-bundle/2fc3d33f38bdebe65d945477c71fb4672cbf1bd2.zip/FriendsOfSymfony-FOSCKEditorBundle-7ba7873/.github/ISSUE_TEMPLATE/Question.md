---
name: ❓ Support Question
about: If you have a question 💬, please check out our Slack or StackOverflow!
---

Hi, we try to keep Github issues for bug reports and feature requests only.
If you have a question, please ask it on Stack Overflow or on #ckeditor on [the symfony-devs slack](https://symfony.com/slack-invite).
